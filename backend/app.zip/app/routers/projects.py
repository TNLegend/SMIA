from datetime import datetime
from typing import List, Optional, Dict, Any
from uuid import uuid4

from fastapi import Path, APIRouter, Depends, HTTPException, status, Query, Body, UploadFile, File
from sqlmodel import Session, select

from app.db import SessionLocal
from app.models import (
    AIProject,
    AIProjectCreate,
    AIProjectRead,
    Comment,
    CommentCreate
)
from app.auth import get_current_user, User

router = APIRouter(prefix="/projects", tags=["projects"])


def get_session():
    with SessionLocal() as sess:
        yield sess


@router.post("/", response_model=AIProjectRead, status_code=status.HTTP_201_CREATED)
def create_project(
    payload: AIProjectCreate,
    current_user: User = Depends(get_current_user),
    sess: Session = Depends(get_session),
):
    proj = AIProject.from_orm(payload)
    proj.owner = current_user.username
    sess.add(proj)
    sess.commit()
    sess.refresh(proj)
    return proj


@router.get("/", response_model=List[AIProjectRead])
def list_projects(
    skip: int = Query(0, ge=0),
    limit: int = Query(6, gt=0, le=100),
    status: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    current_user: User = Depends(get_current_user),
    sess: Session = Depends(get_session),
):
    query = select(AIProject)
    if status:
        query = query.where(AIProject.status == status)
    if search:
        pattern = f"%{search}%"
        query = query.where(
            (AIProject.title.ilike(pattern)) |
            (AIProject.description.ilike(pattern)) |
            (AIProject.category.ilike(pattern)) |
            (AIProject.owner.ilike(pattern))
        )
    projects = sess.exec(query.offset(skip).limit(limit)).all()
    return projects


@router.get("/{project_id}", response_model=AIProjectRead)
def read_project(
    project_id: int,
    current_user: User = Depends(get_current_user),
    sess: Session = Depends(get_session),
):
    proj = sess.get(AIProject, project_id)
    if not proj:
        raise HTTPException(status_code=404, detail="Project not found")
    sess.refresh(proj)  # Important pour les champs JSON comme comments
    return proj


@router.put("/{project_id}", response_model=AIProjectRead)
def update_project(
    project_id: int,
    payload: AIProjectCreate,
    current_user: User = Depends(get_current_user),
    sess: Session = Depends(get_session),
):
    proj = sess.get(AIProject, project_id)
    if not proj:
        raise HTTPException(status_code=404, detail="Project not found")
    update_data = payload.dict(exclude_unset=True)
    for key, val in update_data.items():
        setattr(proj, key, val)
    proj.updated_at = datetime.utcnow()
    sess.add(proj)
    sess.commit()
    sess.refresh(proj)
    return proj


@router.delete("/{project_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_project(
    project_id: int,
    current_user: User = Depends(get_current_user),
    sess: Session = Depends(get_session),
):
    proj = sess.get(AIProject, project_id)
    if not proj:
        raise HTTPException(status_code=404, detail="Project not found")
    sess.delete(proj)
    sess.commit()


@router.get("/{project_id}/comments", response_model=List[Comment])
def list_comments(
    project_id: int,
    current_user: User = Depends(get_current_user),
    sess: Session = Depends(get_session),
):
    proj = sess.get(AIProject, project_id)
    if not proj:
        raise HTTPException(status_code=404, detail="Project not found")
    sess.refresh(proj)
    return proj.comments


@router.post("/{project_id}/comments", response_model=Comment, status_code=201)
def create_comment(
        project_id: int,
        payload: CommentCreate = Body(...),
        current_user: User = Depends(get_current_user),
        sess: Session = Depends(get_session),
):
    proj = sess.get(AIProject, project_id)
    if not proj:
        raise HTTPException(status_code=404, detail="Project not found")

    comment = Comment(author=current_user.username, content=payload.content)
    proj.comments = proj.comments + [comment.dict()]  # << FIX ici

    proj.updated_at = datetime.utcnow()
    sess.add(proj)
    sess.commit()
    sess.refresh(proj)
    return comment


@router.put("/{project_id}/comments/{comment_id}", response_model=Comment)
def update_comment(
    project_id: int,
    comment_id: str = Path(...),
    payload: CommentCreate = Body(...),
    current_user: User = Depends(get_current_user),
    sess: Session = Depends(get_session),
):
    proj = sess.get(AIProject, project_id)
    if not proj:
        raise HTTPException(404, "Project not found")

    updated = False
    for c in proj.comments:
        if isinstance(c, dict) and c["id"] == comment_id:
            c["content"] = payload.content
            c["date"] = datetime.utcnow().isoformat()
            updated = True
            break

    if not updated:
        raise HTTPException(404, "Comment not found")

    proj.updated_at = datetime.utcnow()
    sess.add(proj)
    sess.commit()
    sess.refresh(proj)
    return next(filter(lambda c: c["id"] == comment_id, proj.comments))

@router.delete("/{project_id}/comments/{comment_id}", status_code=204)
def delete_comment(
    project_id: int,
    comment_id: str = Path(...),
    current_user: User = Depends(get_current_user),
    sess: Session = Depends(get_session),
):
    proj = sess.get(AIProject, project_id)
    if not proj:
        raise HTTPException(404, "Project not found")

    before = len(proj.comments)
    proj.comments = [c for c in proj.comments if isinstance(c, dict) and c["id"] != comment_id]

    if len(proj.comments) == before:
        raise HTTPException(404, "Comment not found")

    proj.updated_at = datetime.utcnow()
    sess.add(proj)
    sess.commit()
    return

